"use strict";

const crypto = require("node:crypto");

function secret(bytes = 48) {
  return crypto.randomBytes(bytes).toString("base64url");
}

console.log("Generate these once. Do not upload or share their values.\n");
console.log(`BOT_SYNC_TOKEN=${secret()}`);
console.log(`SESSION_PEPPER=${secret()}`);
